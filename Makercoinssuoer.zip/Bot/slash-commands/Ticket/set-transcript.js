const {
    Client,
    Collection,
    Discord,
    createInvite,
    ChannelType,
    WebhookClient,
    PermissionFlagsBits,
    GatewayIntentBits,
    Partials,
    ApplicationCommandType,
    ApplicationCommandOptionType,
    Events,
    Message,
    StringSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ContextMenuCommandBuilder,
    SlashCommandBuilder,
    REST,
    Routes,
    GatewayCloseCodes,
    ButtonStyle,
    PermissionOverwriteManager,
    ActionRowBuilder,
    ButtonBuilder,
    EmbedBuilder,
    ChatInputCommandInteraction
} = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-Database/Settings/Ticket.json")

module.exports = {
    data: new SlashCommandBuilder()
        .setName('transcript-setup')
        .setDescription('Create new ticket panal.')
        .addChannelOption(channel => channel
            .setName("channel")
            .setDescription("Pick channel to be transcript log.")
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText))
    ,
    type: "Ticket",
    botP: [],
    userP: [PermissionFlagsBits.Administrator],
    P: "Administrator",
    ownerOnly: false,
    /**
* @param {ChatInputCommandInteraction} interaction
*/
    async run(client, interaction, language, reply, replyEmbeds, name) {
        try {
            let channel = interaction.options.getChannel("channel")

            db.set("tranScript_" + interaction.guild.id, channel.id).then(() =>{
                interaction.reply({content: reply.Ticket.Reply36.replace("[CHANNEL]", channel), ephemeral:true})
            })
        } catch (error) {
            console.log(error)
            return interaction.reply({ embeds: [replyEmbeds.errorEmbed], ephemeral: true, allowedMentions: { repliedUser: false } })
        }
    },
};